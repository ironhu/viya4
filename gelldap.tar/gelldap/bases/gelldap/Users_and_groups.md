# Users and Passwords

These are the default account and passwords available in GELLDAP

| username    | password |
|-------------|----------|
| `sasadm`    | `lnxsas` |
| `geladm`    | `lnxsas` |
| `sastest1`  | `lnxsas` |
| `sastest2`  | `lnxsas` |
| `ahmed`     | `lnxsas` |
| `alex`      | `lnxsas` |
| `amanda`    | `lnxsas` |
| `delilah`   | `lnxsas` |
| `douglas`   | `lnxsas` |
| `fay`       | `lnxsas` |
| `fernanda`  | `lnxsas` |
| `fiona`     | `lnxsas` |
| `frank`     | `lnxsas` |
| `fred`      | `lnxsas` |
| `hamish`    | `lnxsas` |
| `hazel`     | `lnxsas` |
| `heather`   | `lnxsas` |
| `helena`    | `lnxsas` |
| `henrik`    | `lnxsas` |
| `hugh`      | `lnxsas` |
| `santiago`  | `lnxsas` |
| `sarah`     | `lnxsas` |
| `sasha`     | `lnxsas` |
| `sean`      | `lnxsas` |
| `sebastian` | `lnxsas` |
| `shannon`   | `lnxsas` |
| `sheldon`   | `lnxsas` |
| `sophia`    | `lnxsas` |